== Copyright ==

Fashion Store lite WordPress Theme, Copyright 2016 RGB Classic
Fashion Store lite is distributed under the terms of the GNU GPL
License URI: http://www.gnu.org/licenses/gpl-2.0.html




Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
Bootstrap 3 Framework  http://getbootstrap.com - Licensed under the [MIT License] (http://opensource.org/licenses/mit-license.html)


https://pixabay.com/en/instagram-cohesion-wedding-flowers-1355473/ CC0 Public Domain