<?php get_header(); ?>


<section class="main_content">
		<div class="container">
			<div class="content-text">






						<aside class="sidebar-right1">
									<?php woocommerce_content(); ?>
						</aside>

							</div>
						</div>
	
</section>




<?php
get_footer();
