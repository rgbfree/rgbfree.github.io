=== Simple White lite ===

License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
Bootstrap 3 Framework  http://getbootstrap.com - Licensed under the [MIT License] (http://opensource.org/licenses/mit-license.html)
wp_bootstrap_navwalker https://github.com/twittem/wp-bootstrap-navwalker GPL-2.0+
