<?php get_header(); ?>


<section class="main_content">
		<div class="container"><div class="content-text">
			<div class="row">






				<div class="col-md-12">
						<aside class="sidebar-right1">

		<?php
		while ( have_posts() ) : the_post();

		get_template_part( 'template-parts/content', 'page' );

			the_post_navigation();


			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile;
		?>
</aside>
								</div>
							</div>
						</div>
</div>
	</section>















<?php
get_footer();
