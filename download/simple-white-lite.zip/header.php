<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">







	<?php wp_head(); ?>































































































	</head>

<body <?php body_class(); ?>>
<div id="page" class="site">




	<header class="top_header">
		<div class="container">
						<div class="col-md-4">
							<div class="header-top1"><aside><?php dynamic_sidebar( 'sidebar-2' ); ?></aside></div>
						</div>

			<div class="col-md-4">
				<div class="row">
					<div class="site-branding">
						<?php global $redux_demo; $logo = ! empty ( $redux_demo['logo-upload']['url'] ) ? $redux_demo['logo-upload']['url'] : '' ;?>
						<h5 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
						<?php  if( empty($logo) ) { bloginfo( 'name' );  ?></a></h5>
					<h6 class="site-description"><?php bloginfo( 'description' ); } else { ?><img src="<?php echo $logo; ?>"/></a><?php } ?></h6>
					</div>
				</div>
			</div>

			

				<div class="col-md-4">
					<div class="row">
					<div class="header-cart-menu">
							<div class="header-cart">
								<?php if (class_exists('woocommerce')) :?>
									<?php global $woocommerce; ?>
									<span class="dashicons dashicons-cart"></span> <a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'simple-white-lite'); ?>"> <?php echo $woocommerce->cart->get_cart_total(); ?></a>
								<?php endif; ?>
							</div>


				  	</div>
					</div>
			</div>



		</div>
	</header>
<div class="container">
<div class="menu-header">
		<div class="container">
				<div class="col-md-12">
					<div class="row">
							<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
					</div>
			</div>
		</div>
</div>
</div>
	<div id="content" class="site-content">
